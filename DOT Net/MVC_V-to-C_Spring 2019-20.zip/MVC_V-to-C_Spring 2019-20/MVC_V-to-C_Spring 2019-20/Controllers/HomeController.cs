﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_V_to_C_Spring_2019_20.Controllers
{
    public class Person
    {
        public string Username { get; set; }
        public string Email { get; set; }
    }

  
    public class HomeController : Controller
    {
       
        //public ActionResult Index()
        //{
        //    if (Request.HttpMethod == "GET")
        //    {
        //        return View();
        //    }
        //    else
        //    {
        //        return Content(Request["email"].ToString());
        //    }
        //}

        //public string Another()
        //{
        //    return Request["username"].ToString();
        //}

        //public string Another(string username,string email)
        //{
        //    return username;
        //}

        //public string Another(FormCollection collection)
        //{
        //    return collection["email"];
        //}

        //public string Another(Person p)
        //{
        //    return p.Email;
        //}

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(Person p)
        {
            return RedirectToAction("Another",p); ;
        }
        public string Another(Person p)
        {
            return "It Works"+"->"+p.Email;
        }
    }
}