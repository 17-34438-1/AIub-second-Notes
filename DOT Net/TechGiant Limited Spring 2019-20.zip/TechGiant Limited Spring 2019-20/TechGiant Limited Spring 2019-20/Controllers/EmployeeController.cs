﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TechGiant_Limited_Spring_2019_20.Models;
using TechGiant_Limited_Spring_2019_20.Repository;

namespace TechGiant_Limited_Spring_2019_20.Controllers
{
    public class EmployeeController : Controller
    {
        IRepository<Employee> empRepo = new EmployeeRepository();
        // GET: Employee
        public ActionResult Index()
        {
            return View(empRepo.GetAll());
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            empRepo.Insert(emp);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            return View(empRepo.Get(id));
        }

        [HttpPost]
        public ActionResult Edit(Employee emp)
        {
            empRepo.Update(emp);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            return View(empRepo.Get(id));
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult ConfirmDelete(int id)
        {
            empRepo.Delete(id);
            return RedirectToAction("Index");
        }
    }
}