﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Extension_Lambda_List_LINQ
{
    class Person
    {
        public string Name { get; set; }
    }

    static class Another
    {
        public static void ExtensionMethod(this Person p,int i)
        {
            Console.WriteLine(p.Name+i);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            
            Person person = new Person() { Name="abc"};
            //person.ExtensionMethod(10);
            //List<string> list = new List<string>();
            //list.Add("Jan");
            //list.Add("Feb");
            //list.Add("Marc");
            //list.Sort();
            //Console.WriteLine(list[1]);
            //Console.WriteLine(list.ElementAt(1));
            //foreach(var item in list)
            //{
            //    Console.Write(item+" ");
            //}

            int[] arr = {8,9,1,2,6,7,3,4,10 };
            //LINQ-Language Integrated Query
            //string sql = "SELECT * FORM Persons";

            //var list = from i1 in arr
            //           where i1 > 5 && i1 % 2 == 0
            //           orderby i1 descending
                
            //           select i1;

            //Extension Method and Lambda Expression

            //var list = arr.Where(x=> x>5).OrderByDescending(i=>i);
            //var list = arr.Where(x => x > 5).Skip(1).Take(2);
            //var list = arr.SingleOrDefault(x => x % 5==0);

            var list = arr.FirstOrDefault();

            Console.WriteLine(list);
            //foreach(var item in list)
            //{
            //    Console.WriteLine(item);
            //}
        }
    }
}
