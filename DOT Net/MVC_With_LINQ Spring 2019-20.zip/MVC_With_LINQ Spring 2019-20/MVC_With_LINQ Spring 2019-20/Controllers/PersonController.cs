﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_With_LINQ_Spring_2019_20.Controllers
{
    public class PersonController : Controller
    {
        PersonDbDataContext context = new PersonDbDataContext();
        // GET: Person
        public ActionResult Index()
        {
            var list = context.Persons.ToList();
            return View(list);
        }
        public ActionResult Details(int id)
        {
            var person = context.Persons.SingleOrDefault(x=> x.Id==id);
            return View(person);
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            var person = context.Persons.SingleOrDefault(x => x.Id == id);
            return View(person);
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var person = context.Persons.SingleOrDefault(x => x.Id == id);
            return View(person);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Person p)
        {
            context.Persons.InsertOnSubmit(p);
            context.SubmitChanges();
            return RedirectToAction("Details", new { p.Id});
        }
        [HttpPost,ActionName("Delete")]
        public ActionResult ConfirmDelete(Person p)
        {
            var person=context.Persons.SingleOrDefault(x=>x.Id==p.Id);
            context.Persons.DeleteOnSubmit(person);
            context.SubmitChanges();
            return RedirectToAction("Index");
        }
        [HttpPost]
        public ActionResult Edit(Person p)
        {
            var person = context.Persons.SingleOrDefault(x => x.Id == p.Id);
            person.Name = p.Name;
            person.Email = p.Email;
            context.SubmitChanges();
            return RedirectToAction("Index");
        }
    }
}