﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Repository_Pattern_with_ADO.NET.Models
{
    public class PersonRepository
    {
        DataAccess data;
        public PersonRepository()
        {
            data = new DataAccess();
        }

        public List<Person> GetAll()
        {
            string sql = "SELECT * FROM Persons";
            SqlDataReader reader = data.GetData(sql);
            List<Person> personList = new List<Person>();
            while (reader.Read())
            {
                Person p = new Person();
                p.Id = Convert.ToInt32(reader["Id"]);
                p.Name = reader["Name"].ToString();
                p.Email = reader["Email"].ToString();
                personList.Add(p);
            }
            return personList;
        }

        public Person Get(int id)
        {
            //string sql = "SELECT * FROM Persons WHERE Id="+id;
            //string sql = "SELECT * FROM Persons WHERE Id= OR 1=1--";
            string sql = "SELECT * FROM Persons WHERE Id=@userId";
            SqlDataReader reader = data.GetData(sql,id);
            Person p = new Person();
            if(reader.Read())
            {
                
                p.Id = Convert.ToInt32(reader["Id"]);
                p.Name = reader["Name"].ToString();
                p.Email = reader["Email"].ToString();
                
            }
            return p;
        }

        public int Update(Person person)
        {
            string sql = "UPDATE Persons SET Name='"+person.Name+"',Email='"+person.Email+"' WHERE Id="+person.Id;
            return data.ExecuteQuery(sql);
        }
        public int Insert(Person person)
        {
            string sql = "INSERT INTO Persons(Name,Email) VALUES('"+person.Name+"','"+person.Email+"')";
            return data.ExecuteQuery(sql);
        }

        public int Remove(int id)
        {
            string sql = "DELETE FROM Persons WHERE Id="+id;
            return data.ExecuteQuery(sql);
        }
    }
}