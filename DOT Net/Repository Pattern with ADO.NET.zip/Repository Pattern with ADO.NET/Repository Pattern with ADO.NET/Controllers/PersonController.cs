﻿using Repository_Pattern_with_ADO.NET.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Repository_Pattern_with_ADO.NET.Controllers
{
    public class PersonController : Controller
    {
        PersonRepository repo = new PersonRepository();
        // GET: Person
        public ActionResult Index()
        {
            return View(repo.GetAll());
        }
        public ActionResult Details(int id)
        {
            return View(repo.Get(id));
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            return View(repo.Get(id));
        }
        [HttpPost]
        public ActionResult Edit(Person p)
        {
            repo.Update(p);
            return RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            return View(repo.Get(id));
        }

        [HttpPost,ActionName("Delete")]
        public ActionResult ConfirmDelete(int id)
        {
            repo.Remove(id);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(Person p)
        {
            repo.Insert(p);
            return RedirectToAction("Details", new { id=4});
        }
    }
}